package orderDishes;
/**
 * @description ����������ʾ�û����ѵ�����
 * @author ������
 * @date 2017/10/21
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class showOrderDetail extends JFrame {
	private JTable table;
	private JLabel allMoney;
	private JTextField showMoneyText;
	private int sum;
	
	public showOrderDetail(int tableIndex) throws Exception {
		this.setTitle("������ϸ");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		String sql = "select Dname,Dprice,Dnum,Dsum from table" + String.valueOf(tableIndex);
		DataOperator DO = new DataOperator();
		table = DO.getTable(sql);
		JScrollPane js = new JScrollPane(table);
		this.add(js);
		int rowNumber = table.getRowCount();
		sum = 0;
		for(int i = 0; i < rowNumber; i++) {
			String temp = String.valueOf(table.getValueAt(i, 3));
			sum += Integer.parseInt(temp);
		}
		JPanel bottomPanel = new JPanel();
		FlowLayout fl = new FlowLayout(FlowLayout.RIGHT,20,50);
		bottomPanel.setLayout(fl);
		allMoney = new JLabel("�ϼ�:");
		showMoneyText = new JTextField(20);
		showMoneyText.setText(String.valueOf(sum));
		bottomPanel.add(allMoney);
		bottomPanel.add(showMoneyText);
		this.add(BorderLayout.SOUTH,bottomPanel);
		this.pack();
	}
}
