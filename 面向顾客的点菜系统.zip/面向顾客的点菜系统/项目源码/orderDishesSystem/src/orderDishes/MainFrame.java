package orderDishes;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;

/**
 * @description 该类时点餐系统的主类
 * @author 温雅新
 * @date 2017/10/13
 */
public class MainFrame extends JFrame implements ActionListener {

	private JLabel tableIndex;     		//静态文本用来显示“请输入桌号：”这条文本
	private JTextField tableIndexText;  //用来接收桌号的文本框
	private JLabel date;                //用来显示“点菜日期”的静态文本
	private JTextField dateText;            	//用来显示日子的文本框
    private HashSet<String> idSet = new HashSet<String>(); 
    private String[] timeArray = new String[20];
    //集合里面的元素唯一，当某桌有客人的时候，不能输入该桌号点餐，用来防止输入出错
    private JButton meatDishes;    	   //荤菜按钮       
    private JButton vegetableDishes;   //素菜按钮
    private JButton stapleDishes;      //主食按钮
    private JButton soupDishes;        //汤粥按钮
    private JButton showDetail;        //显示订单详情按钮
    private JButton stopOrder;         //结束点菜按钮
    private JButton payMoney;		   //付款按钮
    /**
     * @description MainFram类的构造函数，完成该类对象的初始化工作
     * @param 无参数
     * @return 无返回值
     */
    public MainFrame() {
    	this.setTitle("欢迎点菜");   //设置窗体标题
    	this.setVisible(true);     //设置窗体可见，窗体该属性默认不可见，果果忘记，窗体存在但是看不到
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //设置点击关闭按钮关闭
    	tableIndex = new JLabel("请输入您的桌号:");   			//实例话静态文本
    	tableIndexText = new JTextField(15);      			//实例化文本框
    	date = new JLabel("点餐日期与时间:");       			//实例化静态文本
    	dateText = new JTextField(20);            			//实例化文本框
    	//为接收桌号的文本框设置事件监听器以便在输入回车的时候触发事件
    	tableIndexText.addActionListener(this);
    	
    	/*该界面设计窗体使用默认布局，将界面分为上中下三个部分，分别由
    	 * upPanel,middlePanel,bottomPanel构成。
    	 * 三个面板使用流动布局，（当然使用其他布局方式也可以）
    	 * 但是我根据系统界面特征，选择流动布局设计简单
    	 * */
    	JPanel upPanel = new JPanel();    
    	FlowLayout fl = new FlowLayout(FlowLayout.CENTER,20,50);
    	upPanel.setLayout(fl);   //设置面板布局方式为流动布局
    	//将第一模块的控件添加到这个面板上来
    	upPanel.add(tableIndex); 
    	upPanel.add(tableIndexText);
    	upPanel.add(date);
    	upPanel.add(dateText);
    	this.add(BorderLayout.NORTH,upPanel); 
    	//将该面板添加到窗体北部（也就是上方）
    	
    	//实例化四个按钮
    	meatDishes = new JButton("荤菜");
    	vegetableDishes = new JButton("素菜");
    	stapleDishes = new JButton("主食");
    	soupDishes = new JButton("汤粥");
    	
    	//只有在输入桌号的前提下，四个按钮才可用，所以初始化为按钮不可用
    	meatDishes.setEnabled(false);
    	vegetableDishes.setEnabled(false);
    	stapleDishes.setEnabled(false);
    	soupDishes.setEnabled(false);
    	
    	//为四个按钮添加事件监听器
    	meatDishes.addActionListener(this);
    	vegetableDishes.addActionListener(this);
    	stapleDishes.addActionListener(this);
    	soupDishes.addActionListener(this);
    	
    	//中部面板，采用的布局方式是用box实现
    	JPanel middlePanel = new JPanel();  
    	//为该面板添加带标题的边框，一边用户知道这些按钮的作用
    	middlePanel.setBorder(BorderFactory.createTitledBorder("菜品分类"));
    	//基础box,是水平的，用于容纳两个竖直的box
    	Box baseBox = Box.createHorizontalBox();
    	//一个竖直的box
    	Box box1 = Box.createVerticalBox();
    	box1.add(Box.createVerticalStrut(50)); 	//添加间距
    	box1.add(meatDishes);                  	//添加按钮
    	box1.add(Box.createVerticalStrut(100)); //添加间距 
    	box1.add(stapleDishes);                 //添加按钮
    	Box box2 = Box.createVerticalBox();     //一个竖直的box
    	box2.add(Box.createVerticalStrut(50));
    	box2.add(vegetableDishes);
    	box2.add(Box.createVerticalStrut(100));  
    	box2.add(soupDishes);
    	//把两个竖向的box添加到横向的baseBox里面
    	baseBox.add(box1);
    	baseBox.add(Box.createHorizontalStrut(150)); 
    	baseBox.add(box2);
    	middlePanel.add(baseBox);
    	this.add(middlePanel);
    	//BorderLayout布局不指定方向，默认添加到中部
    	
    	//实例化三个按钮
    	showDetail = new JButton("显示点菜明细");
    	stopOrder = new JButton("结束本次点菜"); 
    	payMoney = new JButton("结账");
    	
    	//只有在输入桌号的前提下，这两个按钮才可用，初始设置为不可用
    	showDetail.setEnabled(false);
    	stopOrder.setEnabled(false);
    	
    	//为三个按钮添加事件监听器
    	showDetail.addActionListener(this);
    	stopOrder.addActionListener(this);
    	payMoney.addActionListener(this);
    	JPanel bottomPanel = new JPanel();
    	FlowLayout f2 = new FlowLayout(FlowLayout.CENTER,100,50);
    	bottomPanel.setLayout(f2);
    	bottomPanel.add(showDetail);
    	bottomPanel.add(stopOrder);
    	bottomPanel.add(payMoney);
    	this.add(BorderLayout.SOUTH,bottomPanel);
    	this.setBounds(500,100,800,600); //设置窗体大小
    	this.setResizable(false);        //设置窗体大小不可变
    }
    
	//@Override
    /**@description 该函数用于响应各个控件触发的事件
     * @param 事件
     * @return 无
     */
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		/**
		 * 我设计的系统，默认饭店有15桌，所以输入桌号后，先
		 * 转化成整数，然后判断做好是否合法，如果合法，通过
		 * 集合判断该桌子是否已有客人，如果有客人，则提示
		 * 用户选择其他桌，否则将该桌号插入集合，让用户进行
		 * 点菜。
		 */
		if(event.getSource() == tableIndexText) {
			String id = tableIndexText.getText();
			//如果桌号在集合中，该桌已有客人
			if(!idSet.add(id)) {
				JOptionPane.showMessageDialog(this,"该桌已有客人，请选择其他桌号.");
			}else {
				int num = Integer.parseInt(id);
				//判断桌号输入是否合法
				if(num<0 && num>15) {  
					JOptionPane.showMessageDialog(this, "桌号输入错误，请重新输入");
				}else {
					//放入集合
					idSet.add(id);
					//获取当前事件并显示
					Date nowTime = new Date();
					SimpleDateFormat matter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String date = matter.format(nowTime);
					this.dateText.setText(date);
					int index = Integer.parseInt(id);
					timeArray[index] = dateText.getText();
					//设置这些控件不可用，直到用户下单恢复其可用
					tableIndexText.setEditable(false);
					dateText.setEditable(false);
					
					//点菜按钮恢复成可用状态
					meatDishes.setEnabled(true);
			    	vegetableDishes.setEnabled(true);
			    	stapleDishes.setEnabled(true);
			    	soupDishes.setEnabled(true);
					
			    	showDetail.setEnabled(true);
			    	stopOrder.setEnabled(true);
				}
			}
		} 
		/**
		 * 如果事件源是荤菜按钮，则说明用户要点荤菜，调用选菜类，通过选菜类的
		 * 构造函数把桌号和菜品所属类型信息一并传入。
		 */
		if(event.getSource() == meatDishes) {
			try {
				int num = Integer.parseInt(tableIndexText.getText());
				chooseDishes cd = new chooseDishes(num,"meatdishestable");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/**
		 * 如果事件源是素菜按钮，则说明用户要点素菜，调用选菜类，通过选菜类的
		 * 构造函数把桌号和菜品所属类型信息一并传入。
		 */
		if(event.getSource() == vegetableDishes) {
			try {
				int num = Integer.parseInt(tableIndexText.getText());
				chooseDishes cd = new chooseDishes(num,"vegetableDishesTable");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/**
		 * 如果事件源是主食按钮，则说明用户要点主食，调用选菜类，生成选菜类的实例时
		 * 通过构造函数把桌号和菜品所属类型信息一并传入
		 */
		if(event.getSource() == stapleDishes) {
			try {
				int num = Integer.parseInt(tableIndexText.getText());
				chooseDishes cd = new chooseDishes(num,"stapleDishesTable");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		/**
		 * 如果事件源是汤粥按钮，则说明用户要点汤粥，调用选菜类，生成选菜类的实例时通过
		 * 其构造函数把桌号和菜品所属类型信息一并传入。
		 */
		if(event.getSource() == soupDishes) {
			try {
				int num = Integer.parseInt(tableIndexText.getText());
				chooseDishes cd = new chooseDishes(num,"soupDishesTable");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/**
		 * 如果事件源是显示点菜明细，生成showOrderDetail类，将该桌用户
		 * 所点菜的信息弹出供用户阅览。
		 */
		if(event.getSource() == showDetail) {
			int num = Integer.parseInt(tableIndexText.getText());
			try {
				showOrderDetail show = new showOrderDetail(num);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/**
		 * 如果事件源是结束点菜（stopOrder）,则恢复其他按钮可用即可，可以
		 * 让其他桌的客人点菜
		 */
		if(event.getSource() == stopOrder) {
			tableIndexText.setText("");
			dateText.setText("");
			tableIndexText.setEditable(true);
			dateText.setEditable(true);
			meatDishes.setEnabled(false);
			vegetableDishes.setEnabled(false);
			stapleDishes.setEnabled(false);
			soupDishes.setEnabled(false);
			showDetail.setEnabled(false);
			stopOrder.setEnabled(false);
		}
		/**
		 * 如果事件源是付款(payMoney)，弹出询问框输入要结账的桌号
		 * 如果该桌号在集合中存在，则可以结账，否则输入出错，同样
		 * 显示账单详情，让用户浏览，然后清空数据库中该桌号对应点菜表
		 * 的信息，并将该信息备份到文本文档中，生成一条记录，留给商家
		 * 备份。
		 */
		if(event.getSource() == payMoney) {  	///结账
			String tableId = JOptionPane.showInputDialog(null,"输入要结算的桌号:\n");
			int number = Integer.parseInt(tableId);
			String _number = String.valueOf(number);
			if(!idSet.add(_number)) {
				try {
					showOrderDetail show = new showOrderDetail(Integer.parseInt(tableId));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					//记录数据后并清除。
				String fileName = "myFile\\record.txt";
				try {
					RandomAccessFile file = new RandomAccessFile(fileName,"rw");
					long fileLength = file.length();					///把文件指针移动到文件尾部
					file.seek(fileLength);
					String str;
					str = "桌号:" + _number  + "  日期:" + timeArray[number] + "\n";
					file.write(str.getBytes("utf-8"));
					DataOperator DO = new DataOperator();
					String sql = "select * from table" + _number;					
					ResultSet rs = DO.getResult(sql);
					int sum = 0;
					while(rs.next()) {
						str = rs.getString(1) + "\t";
						file.write(str.getBytes("utf-8"));
						str = rs.getString(2) + "\t";
						file.write(str.getBytes("utf-8"));
						str = rs.getString(3) + "\t";
						file.write(str.getBytes("utf-8"));
						String temp = rs.getString(4);
						sum = sum + Integer.parseInt(temp);
						str = rs.getString(4) + "\t";
						file.write(str.getBytes("utf-8"));
						str = rs.getString(5) + "\n";
						file.write(str.getBytes("utf-8"));				
						}
						str = "费用合计: " + String.valueOf(sum) + "\n";
						file.close();
						idSet.remove(tableIndexText.getText());  ///从集合中删除桌号。
						sql = "delete from table" + tableIndexText.getText();
						DO.deleteRecord(sql);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			} else {
				JOptionPane.showMessageDialog(this, "桌号输入错误，该桌客人不存在");
			}
		}
	}
	public static void main(String args[]) throws Exception {
		MainFrame mf = new MainFrame();
		//chooseDishes cd = new chooseDishes();
		/*DataOperator DO = new DataOperator();
		String ans[] = DO.SelectOneItem("select Did from meatdishestable");
		for(int i = 0; i < ans.length; i++) {
			if(ans[i] == null) {
				break;
			} else {
				System.out.println(ans[i]);
			}
		}*/
	}

}
