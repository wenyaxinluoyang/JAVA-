package orderDishes;

/**
 * @description 该类实现用户点菜功能
 * @author 温雅新
 * @date 2016/10/15
 */
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class chooseDishes extends JFrame implements ActionListener, ListSelectionListener {

	private String id;                           //菜品编号
	private String name;  		                 //菜品名称
	private String description;                  //菜品描述
	private String price;                        //菜品价格
	private Image image;                         //菜品图片
	private MyCanvas drawArea = new MyCanvas();  //绘制菜品各种信息的画布
	private JLabel dishName;                     //“菜品名称”的静态文本
	private JTextField dishNameText;             //显示菜品名称的文本框
	private JLabel number;               		 //“菜品份数”的静态文本
	private JTextField numberText;               //显示菜品份数的文本框
	private JButton increaseNumber;              //增加菜品份数的按钮
	private JButton descreaseNumber;             //减少菜品份数的按钮
	private JList<String> list1;                 //list1用来显示菜单
	private JList<String> list2;                 //list2用来显示已选菜品
	private DefaultListModel<String> listModel1; //listModel1,listModel2用来构造上面两个list
	private DefaultListModel<String> listModel2;
	private JButton addDish;                     //增加菜品，该按钮作用于list1
	private JButton removeDish;                  //移除菜品，该按钮作用于list2
	private JButton advice;                      //推荐菜品，随机为用户推荐三个菜品
	private JButton stopChoose;                  //下单，点击后关闭界面
	private String[] Did;               		 //存放该类菜品的编号，信息来源于数据库
	private String[] Dname;             		 //存放该类菜品的名称，信息来源于数据库
	private String[] Ddescription;      		 //存放该类菜品的描述，信息来源于数据库
	private String[] Dprice;            		 //存放该类菜品的价格，信息来源于数据库
	private int tableIndex;                      //当前点菜用户的桌号
	private HashSet<String> choosedIdSet = new HashSet<String>();  //已选择菜品编号
	private HashSet<String> unChoosedIdSet = new HashSet<String>(); //未选择菜品编号
	/**
	 * @description 该类的构造函数，用来完成该类对象的初始化工作。
	 * @param num  是从主界面传送进来的当前用户的桌号
	 * @param type 是从主界面传送进来的菜品类型
	 * @throws Exception 执行数据库操作出错时抛出异常
	 */
	public chooseDishes(int num,String type) throws Exception {
	
		//设置窗体标题
		this.setTitle("欢迎选菜");
		//设置窗体可见，窗体默认不可见，如果不设置窗体是隐身的。
		this.setVisible(true);
		//选择dispose_on_close的关闭方式。该方式关闭当前窗体而不会连带关闭父窗体
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);   
		//vis进行初始化工作，刚开始没有任何菜被选，都初始化为false
		tableIndex = num;
		choosedIdSet.clear();
		unChoosedIdSet.clear();
		//窗体布局分为三个部分，用upPanel盛装这部分控件放置窗体北方。
		JPanel upPanel = new JPanel();
		//设置面板的布局方式为流动布局
		FlowLayout fl = new FlowLayout(FlowLayout.CENTER,30,30);
		upPanel.setLayout(fl);
		
		//实例化加入面板的各个控件，实例化一个控件后并为相应的控件添加事件监听器
		dishName = new JLabel("菜品名称:");
		dishNameText = new JTextField(25);
		dishNameText.setEditable(false);
		number = new JLabel("份数:");
		numberText = new JTextField(10);
		numberText.setEditable(false);
		increaseNumber = new JButton("+");
		increaseNumber.addActionListener(this);
		descreaseNumber = new JButton("-");
		descreaseNumber.addActionListener(this);
		
		//将各个控件添加到upPanel上
		upPanel.add(dishName);
		upPanel.add(dishNameText);
		upPanel.add(number);
		upPanel.add(numberText);
		upPanel.add(increaseNumber);
		upPanel.add(descreaseNumber);
		//窗体默认采用bordLayout布局，将该面板放置在窗体上部（窗体北侧）。
		this.add(BorderLayout.NORTH,upPanel);
		
		//根据调用该类时传入的菜品类型，对界面的两个列表进行初始化工作。
		initListModel(type);   
		
		//中部面板主要盛装两个列表和各种点菜的按钮，同样也使用浮动布局
		JPanel middlePanel = new JPanel();
		FlowLayout fl2 = new FlowLayout(FlowLayout.CENTER,50,10);
		middlePanel.setLayout(fl2);
		
		//初始化两个列表，并设定其中项的宽度和高度，设置可视高度，这些控件必须加到ScrollPane里面才能有滚动条
		list1 = new JList<String>(listModel1);
		list2 = new JList<String>(listModel2);
		list1.setFixedCellWidth(220);
		list1.setFixedCellHeight(20);
		list2.setFixedCellWidth(220);
		list2.setFixedCellHeight(20);
		list1.setVisibleRowCount(15);
		list2.setVisibleRowCount(15);
		list1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list1.addListSelectionListener(this);
		list2.addListSelectionListener(this);
		
		//欲想让两个列表有滚动条要将它加入到滚动面板中
		JScrollPane jScrollPane1 = new JScrollPane(list1);
		JScrollPane jScrollPane2 = new JScrollPane(list2);
		
		//实例化四个功能按键，并添加监听器
		addDish = new JButton("添加菜品");
		addDish.addActionListener(this);
		removeDish = new JButton("移除菜品");
		removeDish.addActionListener(this);
		advice = new JButton("推荐菜品");
		advice.addActionListener(this);
		stopChoose = new JButton("结束点菜");
		stopChoose.addActionListener(this);
		
		Box listBox1 = new Box(BoxLayout.Y_AXIS);
		Box listBox2 = new Box(BoxLayout.Y_AXIS);
		listBox1.add(Box.createVerticalStrut(20)); //设纵向间距，不至于两个滚动板顶着上方排列
		listBox2.add(Box.createVerticalStrut(20));
		listBox1.add(jScrollPane1);   			   //listBox1放JScrollPane1
		listBox2.add(jScrollPane2);   			   //listBox2放JScrollPanel
		Box box1 = Box.createVerticalBox();
		box1.add(Box.createVerticalStrut(20));
		box1.add(addDish);
		box1.add(Box.createVerticalStrut(50));
		box1.add(removeDish);
		box1.add(Box.createVerticalStrut(50));
		box1.add(advice);
		box1.add(Box.createVerticalStrut(50));
		box1.add(stopChoose);
		middlePanel.add(listBox1);
		middlePanel.add(box1);
		middlePanel.add(listBox2);
		this.add(middlePanel);
		
		//drawArea = new MyCanvas();
		//drawArea.setValue(name, description, price, image);
		//drawArea继承了Canvas类，用来绘制菜品信息，在此设置其大小
		drawArea.setPreferredSize(new Dimension(400,450));
		//bottomPanel.add(drawArea);
		this.add(BorderLayout.SOUTH,drawArea);
		this.setBounds(500,50,900,900);
		this.setResizable(false);
	}
	/**
	 * @description 该方法用来将相应类型的菜品绑定到列表控件中。
	 * @param arg arg的类型是String,它确定顾客的点餐类型
	 * @return 空
	 * @throws Exception
	 */
	public void initListModel(String arg) throws Exception {
		listModel1 = new DefaultListModel<>();
		listModel2 = new DefaultListModel<>();
		//创建数据库操作对象。
		DataOperator DO = new DataOperator();
		//获取所有该类菜品的编号
		Did = DO.SelectOneItem("select Did from " + arg);
		//获取所有该类菜品的名称
		Dname = DO.SelectOneItem("select Dname from " + arg);
		//获取所有该类菜品的描述
		Ddescription = DO.SelectOneItem("select Ddescription from " + arg);
		//获取所有该类菜品对应的价格
		Dprice = DO.SelectOneItem("select Dprice from " + arg);
		//idArray存放该桌客人已经选择的菜的编号
		String[] idArray = new String[100];
		String[] numArray = new String[100];
		//numArray用来存放该桌客人已经选择的菜的数量
		idArray = DO.SelectOneItem("select Did from table" + String.valueOf(tableIndex));
		numArray = DO.SelectOneItem("select Dnum from table" + String.valueOf(tableIndex));
		//把菜品的名称绑定到list1控件上去。
		for(int i = 0; i < Dname.length; i++) {
			listModel1.addElement(Dname[i]);
			unChoosedIdSet.add(Did[i]);  //开始都假设这些菜没有选
		}
		for(int i = 0; i < idArray.length; i++) {
			if(idArray[i] == null)
				break;
			int id = getIndex(Did,idArray[i]);
			if(id != -1) {
				String temp = Dname[id] + " * " + numArray[i] + "份";
				listModel2.addElement(temp);
				choosedIdSet.add(Did[id]);   //已选菜品编号加入集合
				unChoosedIdSet.remove(Did[id]);  //将菜移除未选菜品
			}
		}
	}
	@Override
	public void valueChanged(ListSelectionEvent event) {
		// TODO Auto-generated method stub
		/*事件源是list1的时候，选中一个菜品，将名称放入顶部菜品名，并
		 * 设置菜的默认份数是1，并调用drawArea的repaint方法绘制
		 * 该菜品的名称，价格，描述，图片等信息供用户参考。
		 */
		if(event.getSource() == list1) {
			String temp = list1.getSelectedValue();
			if(temp != "") {
				dishNameText.setText(temp);
				numberText.setText("1");
			}
			name = list1.getSelectedValue();  //获取名称
			int index = getIndex(Dname,name); //获取该菜在数组中的编号，这样就可以确定该菜的其他信息
			id = Did[index];
			description = Ddescription[index];
			price = Dprice[index];
			Toolkit toolKit = Toolkit.getDefaultToolkit();
			image = toolKit.createImage("pictrue\\" + id + ".png");
			drawArea.setValue(name, description, price, image);
			drawArea.repaint();
		}
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		//如果事件源是添加菜品
		if(event.getSource() == addDish) {
			if(list1.getSelectedValue() != "") {
				String item = list1.getSelectedValue();
				int id = getIndex(Dname,item);
				if(id != -1) {
					try {
						String sql = "select * from table" + String.valueOf(tableIndex) + " where Did='" + Did[id] + "'"; 
						DataOperator DO = new DataOperator();
						boolean flag = DO.existInTable(sql);
						if(flag == false) {  ///记录在数据库中不存在可以添加数据
							item += " * " + numberText.getText() + " 份";
							listModel2.addElement(item);
							int sum = Integer.parseInt(numberText.getText())*Integer.parseInt(Dprice[id]);
							sql = "insert into table" + String.valueOf(tableIndex) + "(Did,Dprice,Dnum,Dsum,Dname) values('" + Did[id] + "','" + Dprice[id] + "','" + numberText.getText() + "','" + String.valueOf(sum) + "','" + Dname[id] + "')";
							DO.insertRecord(sql);  //插入记录
							choosedIdSet.add(Did[id]);
							unChoosedIdSet.remove(Did[id]);
							
						} else {
							JOptionPane.showMessageDialog(this, "该菜品已选过，请选择其他菜品");
						}
					}catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			}
		}else if(event.getSource() == removeDish) {  
			//如果事件源是移除菜品，则我们将list2中选中的菜品移除
			if(list2.getSelectedValue() != "") {
				String temp = list2.getSelectedValue();
				String item = temp.substring(0,temp.indexOf(' '));
				int id = getIndex(Dname,item);
				DataOperator DO;
				try {
					DO = new DataOperator();
					String sql = "delete from table" + String.valueOf(tableIndex) + " where Did='" + Did[id] + "'";
					DO.deleteRecord(sql);
					listModel2.removeElementAt(list2.getSelectedIndex());   ///移除
					unChoosedIdSet.add(Did[id]);    //将菜添加入未选集合
					choosedIdSet.remove(Did[id]);   //将菜从已选集合删除
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				JOptionPane.showMessageDialog(this,"请选中要删除的菜品");
			}
		}
		else if(event.getSource() == list1) {  ///当点中菜品时，显示菜品相关信息。
			if(list1.isSelectionEmpty()==false) {
				dishNameText.setText(list1.getSelectedValue());
				numberText.setText("1");
			}
		}else if(event.getSource() == increaseNumber) {
			//如果点击增加按钮，对应菜的份数增加1.
			int num = Integer.parseInt(numberText.getText());  ///把字符串转化成整数
			num++;  
			numberText.setText(String.valueOf(num));
		}else if(event.getSource() == descreaseNumber) {
			//如果点击减少按钮，对应菜品份数减少1，但是最少是一份
			int num = Integer.parseInt(numberText.getText());  ///把字符串转化成整数
			if(num > 1) {
				num--;
				numberText.setText(String.valueOf(num));
			}
		}else if(event.getSource() == stopChoose) {
			//点击结束点菜的时候，关闭窗体
			this.dispose();
		}else if(event.getSource() == advice) {
			//点击推荐点菜的时候，为顾客推荐3种菜
			int adviceNumber = 3;    ///默认推荐菜品数为3种
			int number = unChoosedIdSet.size();   //未选菜品种类
			if(number < 3)  //未选菜品数目不足三种,则推荐菜品数目就是剩余的菜品数量
				adviceNumber = number;  
			int id;
			if(adviceNumber != 0) {
				 for(int i = 1; i <= adviceNumber; i++) {
				    	number = unChoosedIdSet.size();
				    	id = (int)(Math.random()*number);   //随机选取一个未点的菜品
				    	try {
							//String sql = "select * from table" + String.valueOf(tableIndex) + " where Did='" + Did[id] + "'"; 
				    		DataOperator DO = new DataOperator();
							//boolean flag = DO.existInTable(sql);
							//if(flag == false) {  ///记录在数据库中不存在可以添加数据
								//  String item = Dname[id] + " * " + "1份";
				    		Iterator it = (Iterator) unChoosedIdSet.iterator();  ///获取集合迭代器
				    		int temp = 0;
				    		String item="";
				    		//获取第id个元素
				    		while(it.hasNext()) {
				    			temp++;
				    			if(temp == id) {
				    				item = (String) it.next();
				    				break;
				    			}
				    		}
				    		choosedIdSet.add(item);   		//该菜品加入已选菜品集合
				    		unChoosedIdSet.remove(item);    //该菜品从未选菜品集合中删除
				    		id = getIndex(Did,item);
				    		item = Dname[id] + " * " + "1份";
							listModel2.addElement(item);
							int sum = Integer.parseInt(Dprice[id]);
							String sql = "insert into table" + String.valueOf(tableIndex) + "(Did,Dprice,Dnum,Dsum,Dname) values('" + Did[id] + "','" + Dprice[id] + "','" + "1" + "','" + String.valueOf(sum) + "','" + Dname[id] + "')";
							DO.insertRecord(sql);
						}catch (Exception ex) {
							ex.printStackTrace();
						}
				 }
			}
		}
	}
	///该函数用来查询选中菜品在数组中的编号
	public int getIndex(String[] stringArray,String elem) {
		int id=-1;
		for(int i = 0; i < stringArray.length; i++) {
			if(elem.equals(stringArray[i])) {
				id = i;
				break;
			}
		}
		return id;
	}

}
