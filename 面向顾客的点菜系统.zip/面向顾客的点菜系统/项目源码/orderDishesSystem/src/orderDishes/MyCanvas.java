package orderDishes;

import java.awt.Canvas;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

public class MyCanvas extends Canvas {
	private String name; 		 //菜品名称
	private String description;  //菜品描述
	private String price;        //菜品单价
	private Image image;         //菜品图片
	/**
	 * @description  该函数实现对该类的各个变量赋值。
	 * @param _name          菜品名称
	 * @param _description   菜品描述
	 * @param _price         菜品单价
	 * @param _image         菜品图片
	 */
	public void setValue(String _name,String _description,String _price,Image _image) {
		name = _name;
		description = _description;
		price = _price;
		image = _image;
	}
	//重写paint方法，将菜品的信息绘制到画布上
	public void paint(Graphics g) {
		Font f = new Font("TimesRoman",Font.BOLD,20);
		g.setFont(f);
		g.drawString("名称:" + name,200,50);
		g.drawString("描述:" + description, 300, 430);
		g.drawString("价格:"  + price,600,50);
		g.drawImage(image, 250, 80, 400, 300,this);
	}
}
